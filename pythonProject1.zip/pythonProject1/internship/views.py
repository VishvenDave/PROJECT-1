from django.shortcuts import render
from django.http import HttpResponse, Http404
import requests


# Create your views here.
def index(request):
    records = {}
    url = "http://inshortsapi.vercel.app/news?category"
    response = requests.get(url=url)
    inshorts_data = response.json()
    records['alldata'] = inshorts_data
    return render(request, 'index.html', records)


def about(request):
    return render(request, 'about.html')


def sports(request):
    records = {}
    url = "http://inshortsapi.vercel.app/news?category=sports"
    response = requests.get(url=url)
    inshorts_data = response.json()
    records['sportsdata'] = inshorts_data
    return render(request, 'sports.html',records)

def entertainment(request):
    records = {}
    url = "http://inshortsapi.vercel.app/news?category=Entertainment"
    response = requests.get(url=url)
    ent_data = response.json()
    records['entdata'] = ent_data
    return render(request, 'entertainment.html',records)

def politics(request):
    records = {}
    url = "http://inshortsapi.vercel.app/news?category=politics"
    response = requests.get(url=url)
    pol_data = response.json()
    records['poldata'] = pol_data
    return render(request, 'politics.html',records)



