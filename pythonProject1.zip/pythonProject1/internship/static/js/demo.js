function viewmsg(){
    alert("you clicked")
}