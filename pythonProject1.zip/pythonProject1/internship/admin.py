from django.contrib import admin
from .models import category
from .models import products

admin.site.register(category)
admin.site.register(products)
