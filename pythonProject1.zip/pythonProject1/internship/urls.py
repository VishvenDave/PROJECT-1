from django.urls import path
from . import views

urlpatterns = [
    path('index', views.index, name='index'),
    path('about', views.about, name='about'),
    path('sports',views.sports,name='sports'),
    path('entertainment',views.entertainment,name='entertainment'),
    path('politics', views.politics, name='politics')
]

