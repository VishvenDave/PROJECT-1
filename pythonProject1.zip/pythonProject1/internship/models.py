from django.db import models

class category(models.Model):
    categoryName = models.CharField(max_length=50)

class products(models.Model):
    category_name = models.ForeignKey(category, on_delete=models.CASCADE)
    product_name = models.CharField(max_length=50)
    price = models.IntegerField()
    quantity = models.IntegerField()
    description = models.TextField()
